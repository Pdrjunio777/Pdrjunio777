module.exports = {
  semi: true,
  trailingComma: "es5",
  singleQuote: false,
  tabWidth: 2,
};
