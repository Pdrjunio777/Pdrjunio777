import log from "electron-log/renderer";

export const logger = log.scope("renderer");
