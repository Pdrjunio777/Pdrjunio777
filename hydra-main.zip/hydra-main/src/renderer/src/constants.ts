export const VERSION_CODENAME = "Exodus";
