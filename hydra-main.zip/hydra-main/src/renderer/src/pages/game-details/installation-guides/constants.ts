export const DONT_SHOW_ONLINE_FIX_INSTRUCTIONS_KEY =
  "dontShowOnlineFixInstructions";

export const DONT_SHOW_DODI_INSTRUCTIONS_KEY = "dontShowDodiInstructions";
