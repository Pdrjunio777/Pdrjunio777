export * from "./home/home";
export * from "./game-details/game-details";
export * from "./downloads/downloads";
export * from "./home/search-results";
export * from "./settings/settings";
export * from "./catalogue/catalogue";
