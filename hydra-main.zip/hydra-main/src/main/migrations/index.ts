import { FixRepackUploadDate1715900413313 } from "./1715900413313-fix_repack_uploadDate";
import { AlterLastTimePlayedToDatime1716776027208 } from "./1716776027208-alter_lastTimePlayed_to_datime";

export default [
  FixRepackUploadDate1715900413313,
  AlterLastTimePlayedToDatime1716776027208,
];
